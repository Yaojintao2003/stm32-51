/*
 * buzzer.h
 *
 *  Created on: 2022��1��22��
 *      Author: Administrator
 */




#ifndef BUZZER_BUZZER_H_
#define BUZZER_BUZZER_H_

#include "stm32f1xx_hal.h" //HAL���ļ�����
#include "main.h"
#include "../delay/delay.h"
void BUZZER_SOLO1(void);
void BUZZER_SOLO2(void);


#endif /* BUZZER_BUZZER_H_ */
