/*
 * flash.h
 *
 *  Created on: Oct 21, 2021
 *      Author: Administrator
 */

#ifndef FLASH_FLASH_H_
#define FLASH_FLASH_H_

#include "stm32f1xx_hal.h"

void US_FLASH_WRITE (uint32_t  User_Flash_Add,uint16_t User_Flash_Data);
uint16_t US_FLASH_READ (uint32_t  User_Flash_Add);

#endif /* FLASH_FLASH_H_ */
