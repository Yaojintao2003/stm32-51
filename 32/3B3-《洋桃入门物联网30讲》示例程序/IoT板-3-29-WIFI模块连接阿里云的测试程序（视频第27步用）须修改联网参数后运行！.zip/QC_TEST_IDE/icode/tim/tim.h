/*
 * tim.h
 *
 *  Created on: Apr 23, 2022
 *      Author: Administrator
 */

#ifndef TIM_TIM_H_
#define TIM_TIM_H_

#include "main.h"
#include "../usart/usart.h"

TIM_HandleTypeDef htim2;

#endif /* TIM_TIM_H_ */
